## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- setup-------------------------------------------------------------------
library(dynatop)
data("Swindale")
model <- Swindale$model

## ----model_parts--------------------------------------------------------------
names(model)

## ----model-table, echo=FALSE, results='asis'----------------------------------
tmp <- data.frame(Name=character(0),
                  Class=character(0),
                  Description=character(0),
                  stringsAsFactors=FALSE)
tmp[1,] <- c("hillslope","data frame","Description of the hill slope HRU units")
tmp[2,] <- c("channel","data frame","Description of the channel HRU units")
tmp[3,] <- c("param","numeric","Named vector of paramter values")
tmp[4,] <- c("gauge","data frame","Description of the gauge locations on the channel network")
tmp[5,] <- c("point_inflow","data frame","Description of the locations of point inflows to the channel network")
tmp[6,] <- c("point_inflow","data frame","Description of the locations of point inflows to the channel network")
tmp[7,] <- c("map","list","Data for creating maps of the HSUs")

knitr::kable(tmp,booktabs = TRUE,
             caption="Decription of top level model components")

## ----hillslope_parts----------------------------------------------------------
head(model$hillslope)

## ----hillslope-table, echo=FALSE, results='asis'------------------------------
tmp <- data.frame(Name=character(0),
                  Class=character(0),
                  Unit=character(0),
                  Description=character(0),
                  stringsAsFactors=FALSE)
tmp[1,] <- c("id","integer","-","Unique identifying number of the HSU. These combined with the HSU numbers in the channel table should be unique and take values 1,2,3... gaps")
tmp[2,] <- c("area","numeric","$m^2$","Surface area of the HSU")
tmp[3,] <- c("atb_bar","numeric","??","Topographic index, log if the upslope area divided by tangent of gradient")

tmp[4,] <- c("s_bar","numeric","-","Average gradient")
tmp[5,] <- c("delta_x","numeric","m","Notional length of the HSU")
tmp[6,] <- c("class","integer","-","Classification of HSU e.g. by a combination of topographic index and rainfall input")
tmp[7,] <- c("*_class","integer","-","Parital classification of HSU by the * property e.g. atb_bar for topographic index")
tmp[8,] <- c("precip","character","-","Name of the input series to use for precipitation")
tmp[9,] <- c("pet","character","-","Name of the input series to use for potential evapotranspiration")
tmp[10,] <- c("q_sfmax","character","$m/s$","Maximum flow rate from surface to root zone")
tmp[11,] <- c("s_rzmax","character","$m$","Name of the maximum root zone depth parameter")
tmp[12,] <- c("s_rz0","character","$0-1$","Name of the intial root zone depth parameter. Expressed as fraction of maximum depth")
tmp[13,] <- c("ln_t0","character","-","Name of the saturated conductivity parameter")
tmp[14,] <- c("m","character","-","Name of the exponential transmissivity constant parameter")
tmp[15,] <- c("t_d","character","$s/m$","Name of the unsaturated zone time constant per m of saturated storage deficit parameter.")
tmp[16,] <- c("t_sf","character","$s$","Name of the Surface excess storage time constant parameter")
tmp[17,] <- c("sf_dir","list","-","Description of the surface lateral flow connections - see below")
tmp[18,] <- c("sz_dir","list","-","Description of the surface lateral flow connections - see below")

knitr::kable(tmp,row.names=FALSE,
             caption="Description of hillslope data frame columns")


## ----sf_dir_ex----------------------------------------------------------------
model$hillslope$sf_dir[[1]]

## ----sf-dir-table, echo=FALSE, results='asis'---------------------------------
tmp <- data.frame(Name=c("band","idx","frc"),
                  Class=c("integer","integer","numeric"),
                  Description=c("Indication of computational sequence. HSUs in band $n$ presume that those in bands $1,\\ldots,n-1$ have been solved first.",
                                "id values of the HSUs receiving lateral fluxes",
                                "fraction of lateral flux that the corresponding HSUs in idx receive"),
                  stringsAsFactors=FALSE)

knitr::kable(tmp,row.names=FALSE,
             caption="Description of sf_dir and sz_dir list structures")

## ----channel_parts------------------------------------------------------------
head(model$channel)

## ----channel-table, echo=FALSE, results='asis'--------------------------------
vtmp <- sapply(model$channel,class)
tmp <- data.frame(Column=character(0),
                  Class=character(0),
                  Unit=character(0),
                  Description=character(0),
                  stringsAsFactors=FALSE)
tmp[1,] <- c("id","integer","-","Unique identifying number of the hillslope HRU. These, combined with the id from the hillslope table should for consecuative integers increasing from 1.")
tmp[2,] <- c("area","numeric","$m^2$","Surface area of the HSU in m$^2$")
tmp[3,] <- c("length","numeric","$m$","Length of the channel in metres")
tmp[4,] <- c("precip","character","-","Name of the input series to use for precipitation")
tmp[5,] <- c("pet","character","-","Description","Name of the input series to use for potential evapotranspiration")
tmp[6,] <- c("v_ch","character","-","Name of the channel velocity parameter")
tmp[7,] <- c("flow_dir","list","-","As for sf_sir and sz_dir in the hillslope table with the exclusion of the band")

knitr::kable(tmp,row.names=FALSE,
             caption="Description of channel data frame columns")

## ----param_parts--------------------------------------------------------------
model$param

## ----gauge-table, echo=FALSE, results='asis'----------------------------------
tmp <- data.frame(Column=character(0),
                  Class=character(0),
                  Description=character(0),
                  stringsAsFactors=FALSE)

tmp[1,] <- c("name","character","Unique name to idenfy the gauge. used in the channel routing to name the output.")
tmp[2,] <- c("id","integer","The id of the channel HSU on which the gauge is sited")
tmp[3,] <- c("fraction","numeric","Fraction of the length of the channel HSU from the head where the gauge is located. A value of 1 corresponds to the foot on the channel HSU and 0 the head.")

knitr::kable(tmp,row.names=FALSE,
             caption="Description of gauge data frame columns")

## ----gauge--------------------------------------------------------------------
model$gauge

## ----point-table, echo=FALSE, results='asis'----------------------------------
tmp <- data.frame(Column=character(0),
                  Class=character(0),
                  Description=character(0),
                  stringsAsFactors=FALSE)

tmp[1,] <- c("name","character","Name of the input series to use.")
tmp[2,] <- c("id","integer","The id of the channel HSU on which the gauge is sited")
tmp[3,] <- c("fraction","numeric","Fraction of the length of the channel HSU from the head where the gauge is located. A value of 1 corresponds to the foot on the channel HSU and 0 the head.")

knitr::kable(tmp,row.names=FALSE,
             caption="Description of point inflow data frame columns")

## ----point_inflow-------------------------------------------------------------
model$point_inflow

## ----diffuse-table, echo=FALSE, results='asis'--------------------------------
tmp <- data.frame(Column=character(0),
                  Class=character(0),
                  Description=character(0),
                  stringsAsFactors=FALSE)

tmp[1,] <- c("name","character","Name of the input series to use.")
tmp[2,] <- c("id","integer","The id of the channel HSU on which the gauge is sited")

knitr::kable(tmp,row.names=FALSE,
             caption="Description of point inflow data frame columns")

## ----diffuse_inflow-----------------------------------------------------------
model$diffuse_inflow

