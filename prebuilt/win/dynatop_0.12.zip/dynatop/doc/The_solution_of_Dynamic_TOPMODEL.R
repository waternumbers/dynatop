## ---- include = FALSE---------------------------------------------------------
#output: rmarkdown::html_vignette
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

